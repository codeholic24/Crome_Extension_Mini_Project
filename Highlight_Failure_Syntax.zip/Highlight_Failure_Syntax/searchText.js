document.addEventListener('DOMContentLoaded', function () {
    document.querySelector('button').addEventListener('click', searchText);      
});

function searchText() {

const EL_searchField  = document.querySelector("#searchField");
const EL_searchArea   = document.querySelector("#searchArea");
const EL_searchResult = document.querySelector("#searchResult");  
const EL_searchButton = document.querySelector("#searchButton");


const search = () => {
  const val = EL_searchField.value.trim();
  const txt = EL_searchArea.value.trim();
  const result = txt.split(/\n/).reduce((arr, line, i) => {
    if (line.toLowerCase().includes(val.toLowerCase())) {
      arr.push(`<div class="flex"><i>Line ${i+1}:</i><span>${(line.replace(new RegExp(val, "ig"), "<b>$&</b>"))}</span></div>`);
    }
    return arr;
  }, []);

  EL_searchResult.innerHTML = (!val || !txt) ? "No Result Found !!!" : result.join("");
};

EL_searchField.addEventListener("input", search);
EL_searchArea.addEventListener("input", search);
EL_searchButton.addEventListener("click", search);
search();

}